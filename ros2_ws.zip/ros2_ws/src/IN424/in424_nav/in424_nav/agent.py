__author__ = "Johvany Gustave, Jonatan Alvarez"
__copyright__ = "Copyright 2025, IN424, IPSA 2025"
__credits__ = ["Johvany Gustave", "Jonatan Alvarez"]
__license__ = "Apache License 2.0"
__version__ = "1.0.0"


import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseArray, Pose
from rclpy.qos import qos_profile_sensor_data
from tf_transformations import euler_from_quaternion
from collections import deque

import numpy as np

from .my_common import *    #common variables are stored here


class Agent(Node):
    """
    This class is used to define the behavior of ONE agent
    """
    def __init__(self):
        Node.__init__(self, "Agent")
        
        self.nb_agents = 0

        self.load_params()

        #initialize attributes
        self.frontiers = []
        self.frontiers_msg = PoseArray()
        self.frontiers_msg.header.frame_id = str(self.ns)
        self.objectives = []
        self.objectives_msg = PoseArray()
        self.obstacle_pos = []
        self.no_obstacle_pos = []

        self.objectif = None

        self.agents_pose = [None]*self.nb_agents    #[(x_1, y_1), (x_2, y_2), (x_3, y_3)] if there are 3 agents
        self.x = self.y = self.yaw = None   #the pose of this specific agent running the node

        self.map_agent_pub = self.create_publisher(OccupancyGrid, f"/{self.ns}/map", 1) #publisher for agent's own map
        self.front_agent_pub = self.create_publisher(PoseArray, f"/{self.ns}/frontiers", 1) #publisher for agent's own frontiers
        self.objs_agent_pub = self.create_publisher(PoseArray, f"/{self.ns}/objectives", 1) #publisher for agent's own objectives
        
        self.init_map()

        #Subscribe to agents' pose topic
        odom_methods_cb = [self.odom1_cb, self.odom2_cb, self.odom3_cb]
        for i in range(1, self.nb_agents + 1):  
            self.create_subscription(Odometry, f"/bot_{i}/odom", odom_methods_cb[i-1], 1)
        
        if self.nb_agents != 1: #if other agents are involved subscribe to the merged map topic
            self.create_subscription(OccupancyGrid, "/merged_map", self.merged_map_cb, 1)
            self.create_subscription(PoseArray, "/objectives", self.objectives_cb, 1)
        
        self.create_subscription(LaserScan, f"{self.ns}/laser/scan", self.lidar_cb, qos_profile=qos_profile_sensor_data) #subscribe to the agent's own LIDAR topic
        self.cmd_vel_pub = self.create_publisher(Twist, f"{self.ns}/cmd_vel", 1)    #publisher to send velocity commands to the robot

        #Create timers to autonomously call the following methods periodically
        self.create_timer(0.2, self.map_update) #0.2s of period <=> 5 Hz
        # self.create_timer(0.5, self.strategy)      #0.5s of period <=> 2 Hz
        self.create_timer(1, self.publish_maps) #1Hz
        self.create_timer(1, self.publish_frontiers) #1Hz
        self.create_timer(1, self.publish_objectives) #1Hz
    

    def load_params(self):
        """ Load parameters from launch file """
        self.declare_parameters(    #A node has to declare ROS parameters before getting their values from launch files
            namespace="",
            parameters=[
                ("ns", rclpy.Parameter.Type.STRING),    #robot's namespace: either 1, 2 or 3
                ("robot_size", rclpy.Parameter.Type.DOUBLE),    #robot's diameter in meter
                ("env_size", rclpy.Parameter.Type.INTEGER_ARRAY),   #environment dimensions (width height)
                ("nb_agents", rclpy.Parameter.Type.INTEGER),    #total number of agents (this agent included) to map the environment
            ]
        )

        #Get launch file parameters related to this node
        self.ns = self.get_parameter("ns").value
        self.robot_size = self.get_parameter("robot_size").value
        self.env_size = self.get_parameter("env_size").value
        self.nb_agents = self.get_parameter("nb_agents").value
    

    def init_map(self):
        """ Initialize the map to share with others if it is bot_1 """
        self.map_msg = OccupancyGrid()
        self.map_msg.header.frame_id = "map"    #set in which reference frame the map will be expressed (DO NOT TOUCH)
        self.map_msg.header.stamp = self.get_clock().now().to_msg() #get the current ROS time to send the msg
        self.map_msg.info.resolution = self.robot_size  #Map cell size corresponds to robot size
        self.map_msg.info.height = int(self.env_size[0]/self.map_msg.info.resolution)   #nb of rows
        self.map_msg.info.width = int(self.env_size[1]/self.map_msg.info.resolution)   #nb of columns
        self.map_msg.info.origin.position.x = -self.env_size[1]/2   #x and y coordinates of the origin in map reference frame
        self.map_msg.info.origin.position.y = -self.env_size[0]/2
        self.map_msg.info.origin.orientation.w = 1.0    #to have a consistent orientation in quaternion: x=0, y=0, z=0, w=1 for no rotation
        self.map = np.ones(shape=(self.map_msg.info.height, self.map_msg.info.width), dtype=np.int8)*UNEXPLORED_SPACE_VALUE #all the cells are unexplored initially
        self.w, self.h = self.map_msg.info.width, self.map_msg.info.height  
    

    def merged_map_cb(self, msg):
        """ 
            Get the current common map and update ours accordingly.
            This method is automatically called whenever a new message is published on the topic /merged_map.
            'msg' is a nav_msgs/msg/OccupancyGrid message.
        """
        received_map = np.flipud(np.array(msg.data).reshape(self.h, self.w))    #convert the received list into a 2D array and reverse rows
        for i in range(self.h):
            for j in range(self.w):
                #if ((self.map[i, j] == UNEXPLORED_SPACE_VALUE) and (received_map[i, j] != UNEXPLORED_SPACE_VALUE)) or self.map[i,j] == 0:
                if received_map[i, j] != UNEXPLORED_SPACE_VALUE:
                    self.map[i, j] = received_map[i, j]


    def odom1_cb(self, msg):
        """ 
            @brief Get agent 1 position.
            This method is automatically called whenever a new message is published on topic /bot_1/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 1:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[0] = (x, y)
        # self.get_logger().info(f"Agent 1: ({x:.2f}, {y:.2f})")
    

    def odom2_cb(self, msg):
        """ 
            @brief Get agent 2 position.
            This method is automatically called whenever a new message is published on topic /bot_2/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 2:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[1] = (x, y)
        # self.get_logger().info(f"Agent 2: ({x:.2f}, {y:.2f})")


    def odom3_cb(self, msg):
        """ 
            @brief Get agent 3 position.
            This method is automatically called whenever a new message is published on topic /bot_3/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 3:
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
        self.agents_pose[2] = (x, y)
        #self.get_logger().info(f"Agent 3: ({x:.2f}, {y:.2f})")


    def bresenham(self, x0, y0, x1, y1):
        """ Bresenham's Line Algorithm to get all cells between two points, excluding the endpoints """
        cells = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy

        while True:
            # On ignore le premier et le dernier point
            if (x0, y0) != (x1, y1):  # Enlève les points de départ et d'arrivée
                cells.append((x0, y0))
            if x0 == x1 and y0 == y1:  # Condition de fin de boucle quand on arrive à la destination
                break
            e2 = err * 2
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
        return cells


    def is_inside(self, coor):
        """Vérifie si une cellule est à l'intérieur de la carte."""
        x, y = coor[0], coor[1]
        return 0 <= x < self.h and 0 <= y < self.w


    def map_update(self):
        """ Consider sensor readings to update the agent's map """

        #list_frontier = self.frontier_finder()

        if self.x is None or self.y is None or self.yaw is None:
            return

        # Transformer la position du robot en case libre
        x_map, y_map = 2*self.x, 2*self.y # Convertir les positions de metre à coordonnée
        dx, dy = self.h/2, self.w/2 # Récupération de dx et dy
        vmap_frame = np.array([x_map, y_map, 0, 1]) # Création du vecteur coordonnée dans le référentiel de la map
        transfo_mat = np.array([[1, 0, 0,dx],
                                [0,-1, 0,dy],
                                [0, 0,-1, 0],
                                [0, 0, 0, 1]]) # Création de la matrice de transformation
        # Convertir les coordonnées de la carte en indices de la matrice de la carte
        vorigine_frame = (transfo_mat @ vmap_frame).astype(int)
        x0, y0 = vorigine_frame[0], vorigine_frame[1]

        for pos in self.no_obstacle_pos:
            x_obstacle, y_obstacle = 2*pos[0], 2*pos[1] # Convertir les positions de metre à coordonnée
            vmap_obstacle = np.array([x_obstacle,y_obstacle,0,1]) # Création du vecteur coordonnée dans le référentiel de la map
            # Convertir les coordonnées de la carte en indices de la matrice de la carte
            vorigine_obstacle = (transfo_mat@vmap_obstacle).astype(int)
            x, y = vorigine_obstacle[0], vorigine_obstacle[1]
            if self.is_inside((x, y)):
                for cx, cy in self.bresenham(x0, y0, x, y):
                    if self.is_inside((cx, cy)):
                        self.map[cy, cx] = FREE_SPACE_VALUE
                self.map[y, x] = FREE_SPACE_VALUE

        for pos in self.obstacle_pos:
            x_obstacle, y_obstacle = 2*pos[0],2*pos[1] # Convertir les positions de metre à coordonnée
            
            vmap_obstacle = np.array([x_obstacle,y_obstacle,0,1]) # Création du vecteur coordonnée dans le référentiel de la map
            # Convertir les coordonnées de la carte en indices de la matrice de la carte
            vorigine_obstacle = (transfo_mat@vmap_obstacle).astype(int)
            # Vérifiez que les indices sont dans les limites de la carte
            x, y = vorigine_obstacle[0], vorigine_obstacle[1]

            if x == self.w:
                x = self.w - 1
            if y == self.h:
                y = self.h - 1

            if self.is_inside((x, y)):
                for cx, cy in self.bresenham(x0, y0, x, y):
                    if self.is_inside((cx, cy)):
                        self.map[cy, cx] = FREE_SPACE_VALUE
                self.map[y, x] = OBSTACLE_VALUE

        list_list_frontiers = self.wavefront_frontier_detection((x0, y0))
        # self.get_logger().info(f"Frontiers found: {len(list_list_frontiers)}")

        self.frontiers = []
        self.objectives = []
        for front in list_list_frontiers:
            for coor in front:
                self.frontiers.append(coor)
            coor = self.get_centroide(front)
            self.objectives.append(coor)


    def get_centroide(self, front):
        """Récupère le centroïde d'une frontière."""
        x, y = 0, 0
        for x_, y_ in front:
            x += x_
            y += y_
        x = x // len(front)
        y = y // len(front)
        return x, y


    def lidar_cb(self, msg):
        """ 
            @brief Get messages from LIDAR topic.
            This method is automatically called whenever a new message is published on topic /bot_x/laser/scan, where 'x' is either 1, 2 or 3.
            
            @param msg This is a sensor_msgs/msg/LaserScan message.
        """
        
        ranges = msg.ranges
        angle_increment = msg.angle_increment
        angle_min = msg.angle_min
        self.obstacle_pos = []
        self.no_obstacle_pos = []
        if (self.x   is not None and
            self.y   is not None and
            self.yaw is not None):
            for i, d in enumerate(ranges):
                if d <= 4:
                    obstacle_x = self.x + d * np.cos(self.yaw + angle_min + i*angle_increment)
                    obstacle_y = self.y + d * np.sin(self.yaw + angle_min + i*angle_increment)
                    self.obstacle_pos.append([obstacle_x,obstacle_y])
                else:
                    no_obstacle_x = self.x + 4 * np.cos(self.yaw + angle_min + i*angle_increment)
                    no_obstacle_y = self.y + 4 * np.sin(self.yaw + angle_min + i*angle_increment)
                    self.no_obstacle_pos.append([no_obstacle_x,no_obstacle_y])
        

    def publish_maps(self):
        """ 
            Publish updated map to topic /bot_x/map, where x is either 1, 2 or 3.
            This method is called periodically (1Hz) by a ROS2 timer, as defined in the constructor of the class.
        """
        self.map_msg.data = np.flipud(self.map).flatten().tolist()  #transform the 2D array into a list to publish it
        self.map_agent_pub.publish(self.map_msg)    #publish map to other agents


    def publish_frontiers(self):
        self.frontiers_msg.poses = []
        add_pose_array(self.frontiers_msg, self.frontiers)
        self.front_agent_pub.publish(self.frontiers_msg)


    def publish_objectives(self):
        self.objectives_msg.poses = []
        add_pose_array(self.objectives_msg, self.objectives)
        self.objs_agent_pub.publish(self.objectives_msg)
        # self.get_logger().info(f"Objectives published : {len(self.objectives)}")


    def set_objectif(self, x0, y0):    
        dist = lambda c: (c[0] - x0)**2 + (c[1] - y0)**2
        # set the objectif to the nearest center
        if self.objectives:
            scores = np.array([dist(c) for c in self.objectives])
            i_min = np.argmin(scores)
            self.objectif = self.objectives.pop(i_min)


    def objectives_cb(self, msg):
        """ 
            @brief Get objectives from other agents.
            This method is automatically called whenever a new message is published on topic /objectives.
            
            @param msg This is a geometry_msgs/msg/PoseArray message.
        """
        self.objectives = []
        for pose in msg.poses:
            self.objectives.append((pose.position.x, pose.position.y))


    def strategy(self):
        """ Decision and action layers """
        msg = Twist()


        x_map, y_map = 2*self.x, 2*self.y # Convertir les positions de metre à coordonnée
        dx, dy = self.h/2, self.w/2 # Récupération de dx et dy
        vmap_frame = np.array([x_map, y_map, 0, 1]) # Création du vecteur coordonnée dans le référentiel de la map
        transfo_mat = np.array([[1, 0, 0,dx],
                                [0,-1, 0,dy],
                                [0, 0,-1, 0],
                                [0, 0, 0, 1]]) # Création de la matrice de transformation
        # Convertir les coordonnées de la carte en indices de la matrice de la carte
        vorigine_frame = (transfo_mat @ vmap_frame).astype(int)
        x0, y0 = vorigine_frame[0], vorigine_frame[1]


        # zero the yaw angle
        z = -0.3 * self.yaw
        if 0.0 > abs(z) > 0.3:
            z = 0.3 * z/abs(z)
        msg.angular.z = z
        
        if not self.objectif:
            self.set_objectif(x0, y0)
        else: 
            x, y = self.objectif
            self.get_logger().info(f"Pos: ({x0}, {y0}), Obj: ({x}, {y}), dir: ({x-x0}, {y-y0})")
            if x != x0:
                msg.linear.x = 0.3 * (x - x0)/abs(x - x0)
            else:
                msg.linear.x = 0.0
            if y != y0:
                msg.linear.y = -0.3 * (y - y0)/abs(y - y0)
            else:
                msg.linear.y = 0.0
            
            if abs(x - x0) <= 1 and abs(y - y0) <= 1:
                self.objectif = None # Done

        self.cmd_vel_pub.publish(msg)


    def wavefront_frontier_detection(self, start):
        """Détecte les frontières en utilisant l'algorithme WFD et retourne plusieurs clusters."""
        
        # 1. Map-Open-List          : points that have been enqueued by the outer BFS.
        # 2. Map-Close-List         : points that have been dequeued by the outer BFS.
        # 3. Frontier-Open-List     : points that have been enqueued by the inner BFS.
        # 4. Frontier-Close-List    : points that have been dequeued by the inner BFS.


        visited = np.full_like(self.map, "Unvisited", dtype=object)  # Utilisation d'un tableau de chaînes
        frontier_clusters = []  # Liste des clusters de frontières

        # File principale pour explorer toute la carte
        global_queue = deque([start])  
        visited[start] = 'Map-Open-List'

        while global_queue:
            x, y = global_queue.popleft()

            if visited[x, y] in ['Map-Close-List']:  # Vérification correcte
                continue

            if self.is_frontier(x, y):
                frontier_queue = deque([(x, y)])
                frontier_set = set()
                visited[x, y] = 'Frontier-Open-List'

                while frontier_queue:
                    fx, fy = frontier_queue.popleft()

                    if visited[fx, fy] in ['Map-Close-List', 'Frontier-Close-List']:
                        continue

                    if self.is_frontier(fx, fy):
                        frontier_set.add((fx, fy))

                        # Vérification des 8 directions pour trouver des frontières connectées
                        for dfx, dfy in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, -1), (-1, 1)]:
                            nfx, nfy = fx + dfx, fy + dfy
                            if 0 <= nfx < self.w and 0 <= nfy < self.h:
                                if visited[nfx, nfy] not in ['Frontier-Open-List', 'Frontier-Close-List', 'Map-Close-List']:
                                    visited[nfx, nfy] = 'Frontier-Open-List'
                                    frontier_queue.append((nfx, nfy))

                    visited[fx, fy] = 'Frontier-Close-List'  

                if frontier_set:  # Vérifie qu'on a trouvé un cluster avant de l'ajouter
                    frontier_clusters.append(list(frontier_set))
                    for q in frontier_set:
                        visited[q[0], q[1]] = 'Map-Close-List'

            # Ajout des voisins à la file principale pour exploration
            for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, -1), (-1, 1)]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.w and 0 <= ny < self.h:
                    if visited[nx, ny] not in ['Map-Open-List', 'Map-Close-List']:
                        if any(0 <= nx + ddx < self.w and 0 <= ny + ddy < self.h and visited[nx + ddx, ny + ddy] == 'Map-Open-List'
                           for ddx, ddy in [(0, 1), (1, 0), (0, -1), (-1, 0)]):
                            visited[nx, ny] = 'Map-Open-List'
                            global_queue.append((nx, ny))

            visited[x, y] = 'Map-Close-List'
        
        return frontier_clusters


    def is_frontier(self, x, y):
        """Vérifie si une cellule est une frontière."""
        # if self.map[y, x] != UNEXPLORED_SPACE_VALUE:  # Doit être une cellule inconnue
        if self.map[y, x] != FREE_SPACE_VALUE:  # Doit être une cellule inconnue
            return False
        
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (1, -1), (-1, -1), (-1, 1)]
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            # if self.is_inside((nx, ny)) and self.map[ny, nx] == FREE_SPACE_VALUE:
            if self.is_inside((nx, ny)) and self.map[ny, nx] == UNEXPLORED_SPACE_VALUE:
                return True
        return False


    def wavefront_frontier_detector(self, frontiers_unvisited):
        """Détecte les frontières à partir d'un point de départ."""
        frontiers = []
        
        while frontiers_unvisited:
            front = self.get_one_frontier(frontiers_unvisited)
            frontiers.append(front)

        return frontiers
    
    
    def get_one_frontier(self, front_coords):
        """Récupère une frontière à partir d'une coordonnée."""
        front = []
        coor_init = front_coords[0]
        searching_queue = deque([coor_init])
        while searching_queue:
            x, y = searching_queue.popleft()
            for dx, dy in [(-1, -1), (-1, 0), (-1, 1),
                           ( 0, -1), ( 0, 0), ( 0, 1),
                           ( 1, -1), ( 1, 0), ( 1, 1)]:
                nx, ny = x + dx, y + dy
                if (nx, ny) in front_coords:
                    # self.get_logger().info(f"\t{(nx, ny) = }")
                    front.append((nx, ny))
                    searching_queue.append((nx, ny))
                    front_coords.remove((nx, ny))
        return front


        

def main():
    rclpy.init()

    node = Agent()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()